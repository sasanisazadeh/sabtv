﻿namespace sabtvaokala
{
    partial class AddLawyers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblLawyerName = new System.Windows.Forms.Label();
            this.txtLawyerFirstName = new System.Windows.Forms.TextBox();
            this.txtLawyerLastName = new System.Windows.Forms.TextBox();
            this.lblLawyerLastName = new System.Windows.Forms.Label();
            this.lblNationalCode = new System.Windows.Forms.Label();
            this.txtLawyerNationalCode = new System.Windows.Forms.TextBox();
            this.lblLicenseNumber = new System.Windows.Forms.Label();
            this.lblRegisteryDate = new System.Windows.Forms.Label();
            this.LblLawyerCityJob = new System.Windows.Forms.Label();
            this.txtLicenseNumber = new System.Windows.Forms.TextBox();
            this.txtLawyerCityJob = new System.Windows.Forms.TextBox();
            this.lblPhoneNumber = new System.Windows.Forms.Label();
            this.txtLawyerPhoneNumber = new System.Windows.Forms.TextBox();
            this.lblLawyerAddress = new System.Windows.Forms.Label();
            this.txtLawyerAddress = new System.Windows.Forms.TextBox();
            this.BtnLawyerSave = new System.Windows.Forms.Button();
            this.BtnLawyerEdit = new System.Windows.Forms.Button();
            this.BtnLwyerDelete = new System.Windows.Forms.Button();
            this.BtnLawyerNew = new System.Windows.Forms.Button();
            this.lblShowLawyers = new System.Windows.Forms.Label();
            this.dgvLawyers = new System.Windows.Forms.DataGridView();
            this.BtnLawyerRefresh = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.dtpRegisteryDate = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLawyers)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(471, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "لطفا هنگام درج اطلاعات دقت نموده و مشخصات را دقیق وارد نمایید";
            // 
            // lblLawyerName
            // 
            this.lblLawyerName.AutoSize = true;
            this.lblLawyerName.Location = new System.Drawing.Point(99, 85);
            this.lblLawyerName.Name = "lblLawyerName";
            this.lblLawyerName.Size = new System.Drawing.Size(39, 22);
            this.lblLawyerName.TabIndex = 1;
            this.lblLawyerName.Text = "نام :";
            // 
            // txtLawyerFirstName
            // 
            this.txtLawyerFirstName.Location = new System.Drawing.Point(180, 82);
            this.txtLawyerFirstName.Name = "txtLawyerFirstName";
            this.txtLawyerFirstName.Size = new System.Drawing.Size(254, 28);
            this.txtLawyerFirstName.TabIndex = 2;
            // 
            // txtLawyerLastName
            // 
            this.txtLawyerLastName.Location = new System.Drawing.Point(611, 82);
            this.txtLawyerLastName.Name = "txtLawyerLastName";
            this.txtLawyerLastName.Size = new System.Drawing.Size(254, 28);
            this.txtLawyerLastName.TabIndex = 3;
            // 
            // lblLawyerLastName
            // 
            this.lblLawyerLastName.AutoSize = true;
            this.lblLawyerLastName.Location = new System.Drawing.Point(465, 85);
            this.lblLawyerLastName.Name = "lblLawyerLastName";
            this.lblLawyerLastName.Size = new System.Drawing.Size(107, 22);
            this.lblLawyerLastName.TabIndex = 4;
            this.lblLawyerLastName.Text = "نام خانوادگی :";
            // 
            // lblNationalCode
            // 
            this.lblNationalCode.AutoSize = true;
            this.lblNationalCode.Location = new System.Drawing.Point(940, 82);
            this.lblNationalCode.Name = "lblNationalCode";
            this.lblNationalCode.Size = new System.Drawing.Size(68, 22);
            this.lblNationalCode.TabIndex = 5;
            this.lblNationalCode.Text = "کد ملی :";
            // 
            // txtLawyerNationalCode
            // 
            this.txtLawyerNationalCode.Location = new System.Drawing.Point(1033, 79);
            this.txtLawyerNationalCode.Name = "txtLawyerNationalCode";
            this.txtLawyerNationalCode.Size = new System.Drawing.Size(254, 28);
            this.txtLawyerNationalCode.TabIndex = 6;
            this.txtLawyerNationalCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLawyerNationalCode_KeyPress);
            // 
            // lblLicenseNumber
            // 
            this.lblLicenseNumber.AutoSize = true;
            this.lblLicenseNumber.Location = new System.Drawing.Point(26, 144);
            this.lblLicenseNumber.Name = "lblLicenseNumber";
            this.lblLicenseNumber.Size = new System.Drawing.Size(112, 22);
            this.lblLicenseNumber.TabIndex = 7;
            this.lblLicenseNumber.Text = "شماره پروانه :";
            // 
            // lblRegisteryDate
            // 
            this.lblRegisteryDate.AutoSize = true;
            this.lblRegisteryDate.Location = new System.Drawing.Point(453, 141);
            this.lblRegisteryDate.Name = "lblRegisteryDate";
            this.lblRegisteryDate.Size = new System.Drawing.Size(119, 22);
            this.lblRegisteryDate.TabIndex = 8;
            this.lblRegisteryDate.Text = "تاریخ عضویت :";
            // 
            // LblLawyerCityJob
            // 
            this.LblLawyerCityJob.AutoSize = true;
            this.LblLawyerCityJob.Location = new System.Drawing.Point(864, 141);
            this.LblLawyerCityJob.Name = "LblLawyerCityJob";
            this.LblLawyerCityJob.Size = new System.Drawing.Size(144, 22);
            this.LblLawyerCityJob.TabIndex = 9;
            this.LblLawyerCityJob.Text = "شهر حوزه فعالیت :";
            // 
            // txtLicenseNumber
            // 
            this.txtLicenseNumber.Location = new System.Drawing.Point(180, 138);
            this.txtLicenseNumber.Name = "txtLicenseNumber";
            this.txtLicenseNumber.Size = new System.Drawing.Size(254, 28);
            this.txtLicenseNumber.TabIndex = 10;
            this.txtLicenseNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLicenseNumber_KeyPress);
            // 
            // txtLawyerCityJob
            // 
            this.txtLawyerCityJob.Location = new System.Drawing.Point(1033, 135);
            this.txtLawyerCityJob.Name = "txtLawyerCityJob";
            this.txtLawyerCityJob.Size = new System.Drawing.Size(254, 28);
            this.txtLawyerCityJob.TabIndex = 11;
            // 
            // lblPhoneNumber
            // 
            this.lblPhoneNumber.AutoSize = true;
            this.lblPhoneNumber.Location = new System.Drawing.Point(34, 202);
            this.lblPhoneNumber.Name = "lblPhoneNumber";
            this.lblPhoneNumber.Size = new System.Drawing.Size(104, 22);
            this.lblPhoneNumber.TabIndex = 13;
            this.lblPhoneNumber.Text = "شماره تماس :";
            // 
            // txtLawyerPhoneNumber
            // 
            this.txtLawyerPhoneNumber.Location = new System.Drawing.Point(180, 196);
            this.txtLawyerPhoneNumber.Name = "txtLawyerPhoneNumber";
            this.txtLawyerPhoneNumber.Size = new System.Drawing.Size(254, 28);
            this.txtLawyerPhoneNumber.TabIndex = 14;
            this.txtLawyerPhoneNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLawyerPhoneNumber_KeyPress);
            // 
            // lblLawyerAddress
            // 
            this.lblLawyerAddress.AutoSize = true;
            this.lblLawyerAddress.Location = new System.Drawing.Point(465, 202);
            this.lblLawyerAddress.Name = "lblLawyerAddress";
            this.lblLawyerAddress.Size = new System.Drawing.Size(60, 22);
            this.lblLawyerAddress.TabIndex = 15;
            this.lblLawyerAddress.Text = "آدرس :";
            // 
            // txtLawyerAddress
            // 
            this.txtLawyerAddress.Location = new System.Drawing.Point(611, 196);
            this.txtLawyerAddress.Multiline = true;
            this.txtLawyerAddress.Name = "txtLawyerAddress";
            this.txtLawyerAddress.Size = new System.Drawing.Size(676, 28);
            this.txtLawyerAddress.TabIndex = 16;
            // 
            // BtnLawyerSave
            // 
            this.BtnLawyerSave.Location = new System.Drawing.Point(38, 255);
            this.BtnLawyerSave.Name = "BtnLawyerSave";
            this.BtnLawyerSave.Size = new System.Drawing.Size(168, 48);
            this.BtnLawyerSave.TabIndex = 17;
            this.BtnLawyerSave.Text = "ذخیره";
            this.BtnLawyerSave.UseVisualStyleBackColor = true;
            this.BtnLawyerSave.Click += new System.EventHandler(this.BtnLawyerSave_Click);
            // 
            // BtnLawyerEdit
            // 
            this.BtnLawyerEdit.Location = new System.Drawing.Point(231, 255);
            this.BtnLawyerEdit.Name = "BtnLawyerEdit";
            this.BtnLawyerEdit.Size = new System.Drawing.Size(168, 48);
            this.BtnLawyerEdit.TabIndex = 18;
            this.BtnLawyerEdit.Text = "ویرایش";
            this.BtnLawyerEdit.UseVisualStyleBackColor = true;
            // 
            // BtnLwyerDelete
            // 
            this.BtnLwyerDelete.Location = new System.Drawing.Point(421, 255);
            this.BtnLwyerDelete.Name = "BtnLwyerDelete";
            this.BtnLwyerDelete.Size = new System.Drawing.Size(168, 48);
            this.BtnLwyerDelete.TabIndex = 19;
            this.BtnLwyerDelete.Text = "حذف";
            this.BtnLwyerDelete.UseVisualStyleBackColor = true;
            // 
            // BtnLawyerNew
            // 
            this.BtnLawyerNew.Location = new System.Drawing.Point(611, 255);
            this.BtnLawyerNew.Name = "BtnLawyerNew";
            this.BtnLawyerNew.Size = new System.Drawing.Size(168, 48);
            this.BtnLawyerNew.TabIndex = 20;
            this.BtnLawyerNew.Text = "جدید";
            this.BtnLawyerNew.UseVisualStyleBackColor = true;
            this.BtnLawyerNew.Click += new System.EventHandler(this.BtnLawyerNew_Click);
            // 
            // lblShowLawyers
            // 
            this.lblShowLawyers.AutoSize = true;
            this.lblShowLawyers.Location = new System.Drawing.Point(26, 337);
            this.lblShowLawyers.Name = "lblShowLawyers";
            this.lblShowLawyers.Size = new System.Drawing.Size(233, 22);
            this.lblShowLawyers.TabIndex = 21;
            this.lblShowLawyers.Text = "اسامی اعضا دپارتمان معاضدت :";
            // 
            // dgvLawyers
            // 
            this.dgvLawyers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLawyers.Location = new System.Drawing.Point(27, 388);
            this.dgvLawyers.Name = "dgvLawyers";
            this.dgvLawyers.RowHeadersWidth = 51;
            this.dgvLawyers.RowTemplate.Height = 24;
            this.dgvLawyers.Size = new System.Drawing.Size(1270, 305);
            this.dgvLawyers.TabIndex = 22;
            // 
            // BtnLawyerRefresh
            // 
            this.BtnLawyerRefresh.Location = new System.Drawing.Point(803, 255);
            this.BtnLawyerRefresh.Name = "BtnLawyerRefresh";
            this.BtnLawyerRefresh.Size = new System.Drawing.Size(168, 48);
            this.BtnLawyerRefresh.TabIndex = 23;
            this.BtnLawyerRefresh.Text = "بروز رسانی";
            this.BtnLawyerRefresh.UseVisualStyleBackColor = true;
            this.BtnLawyerRefresh.Click += new System.EventHandler(this.BtnLawyerRefresh_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(990, 255);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(168, 48);
            this.btnClose.TabIndex = 24;
            this.btnClose.Text = "لغو";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dtpRegisteryDate
            // 
            this.dtpRegisteryDate.Location = new System.Drawing.Point(611, 136);
            this.dtpRegisteryDate.Name = "dtpRegisteryDate";
            this.dtpRegisteryDate.Size = new System.Drawing.Size(200, 28);
            this.dtpRegisteryDate.TabIndex = 12;
            // 
            // AddLawyers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1326, 721);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.BtnLawyerRefresh);
            this.Controls.Add(this.dgvLawyers);
            this.Controls.Add(this.lblShowLawyers);
            this.Controls.Add(this.BtnLawyerNew);
            this.Controls.Add(this.BtnLwyerDelete);
            this.Controls.Add(this.BtnLawyerEdit);
            this.Controls.Add(this.BtnLawyerSave);
            this.Controls.Add(this.txtLawyerAddress);
            this.Controls.Add(this.lblLawyerAddress);
            this.Controls.Add(this.txtLawyerPhoneNumber);
            this.Controls.Add(this.lblPhoneNumber);
            this.Controls.Add(this.dtpRegisteryDate);
            this.Controls.Add(this.txtLawyerCityJob);
            this.Controls.Add(this.txtLicenseNumber);
            this.Controls.Add(this.LblLawyerCityJob);
            this.Controls.Add(this.lblRegisteryDate);
            this.Controls.Add(this.lblLicenseNumber);
            this.Controls.Add(this.txtLawyerNationalCode);
            this.Controls.Add(this.lblNationalCode);
            this.Controls.Add(this.lblLawyerLastName);
            this.Controls.Add(this.txtLawyerLastName);
            this.Controls.Add(this.txtLawyerFirstName);
            this.Controls.Add(this.lblLawyerName);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "AddLawyers";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "ثبت وکیل در دپارتمان معاضدت";
            ((System.ComponentModel.ISupportInitialize)(this.dgvLawyers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblLawyerName;
        private System.Windows.Forms.TextBox txtLawyerFirstName;
        private System.Windows.Forms.TextBox txtLawyerLastName;
        private System.Windows.Forms.Label lblLawyerLastName;
        private System.Windows.Forms.Label lblNationalCode;
        private System.Windows.Forms.TextBox txtLawyerNationalCode;
        private System.Windows.Forms.Label lblLicenseNumber;
        private System.Windows.Forms.Label lblRegisteryDate;
        private System.Windows.Forms.Label LblLawyerCityJob;
        private System.Windows.Forms.TextBox txtLicenseNumber;
        private System.Windows.Forms.TextBox txtLawyerCityJob;
        private System.Windows.Forms.Label lblPhoneNumber;
        private System.Windows.Forms.TextBox txtLawyerPhoneNumber;
        private System.Windows.Forms.Label lblLawyerAddress;
        private System.Windows.Forms.TextBox txtLawyerAddress;
        private System.Windows.Forms.Button BtnLawyerSave;
        private System.Windows.Forms.Button BtnLawyerEdit;
        private System.Windows.Forms.Button BtnLwyerDelete;
        private System.Windows.Forms.Button BtnLawyerNew;
        private System.Windows.Forms.Label lblShowLawyers;
        private System.Windows.Forms.DataGridView dgvLawyers;
        private System.Windows.Forms.Button BtnLawyerRefresh;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.DateTimePicker dtpRegisteryDate;
    }
}
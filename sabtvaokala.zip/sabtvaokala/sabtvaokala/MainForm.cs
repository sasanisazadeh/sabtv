﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using sabtvaokala;

namespace sabtvaokala
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void افزودنوویرایشمشخصاتاعضاToolStripMenuItem_Click(object sender, EventArgs e)
        {
               OpenForm(new AddLawyers());
        }

        private void ثبتاطلاعاتاولیهمراجعهکنندهToolStripMenuItem_Click(object sender, EventArgs e)
        {
              OpenForm(new ClientsEntry()); 
        }

        private void خروجToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void OpenForm(Form newForm)
        {
            this.Hide(); // مخفی کردن فرم فعلی
            newForm.FormClosed += (s, args) => this.Show(); // نمایش مجدد هنگام بستن فرم جدید
            newForm.Show();
        }

        private void ثبتکشیکروزانهToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenForm(new BeLawyersInDep());
        }
    }
}

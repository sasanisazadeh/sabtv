﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Globalization;
using sabtvaokala;
using System.Drawing.Printing;


namespace sabtvaokala
{
    public partial class BeLawyersInDep : Form
    {
        public BeLawyersInDep()
        {
            InitializeComponent();
            InitializeForm();
        }
        private void InitializeForm()
        {
            // تنظیمات اولیه فرم
            lblDate.Text = PersianDateTime.Now.ToString("yyyy/MM/dd");
            lblTime.Text = DateTime.Now.ToString("HH:mm");

            // تنظیمات DataGridView
            dgvPresence.RightToLeft = RightToLeft.Yes;
            dgvPresence.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // بارگذاری اولیه داده‌ها
            LoadDailyPresence();
            DisplayStatistics();
        }
        private void LoadLawyerInfo(string searchValue, string searchField)
        {
            string query = $"SELECT * FROM TblLawyers WHERE {searchField} LIKE '%{searchValue}%'";

            using (OleDbConnection conn = ConnectionClass.GetConnection())
            {
                OleDbCommand cmd = new OleDbCommand(query, conn);
                conn.Open();
                OleDbDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    txtLawyerNameInDep.Text = reader["LawyerFirstName"].ToString();
                    txtLawyerFamilyInDep.Text = reader["LawyerLastName"].ToString();
                    txtLicenseNumberInDep.Text = reader["LicenseNumber"].ToString();
                }
            }
        }

        private void LawyersPresence_Load(object sender, EventArgs e)
        {
            ShowPersianDate();
            ShowCurrentTime();

            Timer timer = new Timer { Interval = 1000 };
            timer.Tick += (s, ev) => ShowCurrentTime();
            timer.Start();
        }
        private void ShowPersianDate()
        {
            PersianCalendar pc = new PersianCalendar();
            DateTime now = DateTime.Now;
            lblDate.Text = $"{pc.GetYear(now)}/{pc.GetMonth(now):00}/{pc.GetDayOfMonth(now):00}";
        }

        private void ShowCurrentTime()
        {
            lblTime.Text = DateTime.Now.ToString("HH:mm:ss");
        }

        private void btnSaveDep_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtLicenseNumberInDep.Text))
            {
                MessageBox.Show("لطفاً شماره پروانه را وارد کنید");
                return;
            }

            try
            {
                using (OleDbConnection conn = ConnectionClass.GetConnection())
                {
                    conn.Open();

                    // ثبت در جدول حضور وکلا
                    string insertQuery = @"INSERT INTO TblLawyersPresence 
                                 (LawyerFirstName, LawyerLastName, LicenseNumber, PresenceDate) 
                                 VALUES (?, ?, ?, ?)";
                    OleDbCommand cmd = new OleDbCommand(insertQuery, conn);
                    cmd.Parameters.AddWithValue("@LawyerFirstName", txtLawyerNameInDep.Text);
                    cmd.Parameters.AddWithValue("@LawyerLastName", txtLawyerFamilyInDep.Text);
                    cmd.Parameters.AddWithValue("@LicenseNumber", txtLicenseNumberInDep.Text);
                    cmd.Parameters.AddWithValue("@PresenceDate", DateTime.Now.ToString("yyyy/MM/dd"));

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("حضور وکیل با موفقیت ثبت شد");
                    ClearForm();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا در ثبت اطلاعات: " + ex.Message);
            }
        }

        private void ClearForm()
        {
            txtLawyerNameInDep.Text = "";
            txtLawyerFamilyInDep.Text = "";
            txtLicenseNumberInDep.Text = "";
        }
        private void btnShowWeeklyReport_Click(object sender, EventArgs e)
        {
            dgvPresence.DataSource = GetWeeklyReport();
        }
        private DataTable GetWeeklyReport()
        {
            PersianCalendar pc = new PersianCalendar();
            DateTime today = DateTime.Now;
            DateTime saturday = today.AddDays(-(int)today.DayOfWeek + (int)DayOfWeek.Saturday);
            DateTime friday = saturday.AddDays(6);

            string startDate = $"{pc.GetYear(saturday)}/{pc.GetMonth(saturday):00}/{pc.GetDayOfMonth(saturday):00}";
            string endDate = $"{pc.GetYear(friday)}/{pc.GetMonth(friday):00}/{pc.GetDayOfMonth(friday):00}";
            DataTable dt = new DataTable();
            using (OleDbConnection conn = ConnectionClass.GetConnection())
            {
                conn.Open();
                string selectQuery = "SELECT Date, Name, Family, LicenseNumber FROM LawyersInDepartment WHERE Date BETWEEN ? AND ? ORDER BY Date";
                OleDbCommand cmd = new OleDbCommand(selectQuery, conn);
                cmd.Parameters.AddWithValue("@StartDate", startDate);
                cmd.Parameters.AddWithValue("@EndDate", endDate);
                new OleDbDataAdapter(cmd).Fill(dt);
            }
            return dt;
        }

        private void btnPrintReport_Click(object sender, EventArgs e)
        {
            PrintDocument pd = new PrintDocument();
            pd.PrintPage += new PrintPageEventHandler(PrintReportHandler);

            PrintPreviewDialog ppd = new PrintPreviewDialog();
            ppd.Document = pd;
            ppd.ShowDialog();
        }
        private void PrintReportHandler(object sender, PrintPageEventArgs e)
        {
            DataTable report = GetWeeklyReport();
            float yPos = 0;
            Font font = new Font("Arial", 12);

            var groupedByDate = report.AsEnumerable()
                .GroupBy(row => row.Field<string>("Date"))
                .OrderBy(g => g.Key);
            foreach (var group in groupedByDate)
            {
                e.Graphics.DrawString($"{group.Key}:", font, Brushes.Black, 10, yPos);
                yPos += 20;

                string lawyers = string.Join("، ", group.Select(row => $"{row["Name"]} {row["Family"]}"));
                e.Graphics.DrawString(lawyers, font, Brushes.Black, 30, yPos);
                yPos += 20;

                e.Graphics.DrawString($"تعداد: {group.Count()}", font, Brushes.Black, 30, yPos);
                yPos += 30;
            }
        }

        private void txtLawyerNameInDep_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtLawyerNameInDep.Text))
                LoadLawyerInfo(txtLawyerNameInDep.Text, "LawyerFirstName");
        }

        private void txtLawyerFamilyInDep_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtLawyerFamilyInDep.Text))
                LoadLawyerInfo(txtLawyerFamilyInDep.Text, "LawyerLastName");
        }

        private void txtLicenseNumberInDep_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtLicenseNumberInDep.Text))
                LoadLawyerInfo(txtLicenseNumberInDep.Text, "LicenseNumber");
        }
        private void SearchAndFillLawyerInfo()
        {
            string searchValue = !string.IsNullOrEmpty(txtLicenseNumberInDep.Text) ? txtLicenseNumberInDep.Text :
                                !string.IsNullOrEmpty(txtLawyerNameInDep.Text) ? txtLawyerNameInDep.Text :
                                txtLawyerFamilyInDep.Text;

            if (!string.IsNullOrEmpty(searchValue))
            {
                DataRow lawyerInfo = ConnectionClass.GetLawyerInfo(searchValue);
                if (lawyerInfo != null)
                {
                    txtLawyerNameInDep.Text = lawyerInfo["LawyerFirstName"].ToString();
                    txtLawyerFamilyInDep.Text = lawyerInfo["LawyerLastName"].ToString();
                    txtLicenseNumberInDep.Text = lawyerInfo["LicenseNumber"].ToString();
                }
            }
        }
        public static int GetTodayPresenceCount(string todayDate)
        {
            using (OleDbConnection conn = GetConnection())
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM TblLawyersPresence WHERE PresenceDate = ?";
                OleDbCommand cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("@p1", todayDate);
                return (int)cmd.ExecuteScalar();
            }
        }
        public static int GetWeeklyPresenceCount(string startDate, string endDate)
        {
            using (OleDbConnection conn = GetConnection())
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM TblLawyersPresence WHERE PresenceDate BETWEEN ? AND ?";
                OleDbCommand cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("@p1", startDate);
                cmd.Parameters.AddWithValue("@p2", endDate);
                return (int)cmd.ExecuteScalar();
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sabtvaokala
{
    internal class Clients
    {
        internal class Client
        {
            public string LawyerFirstName { get; set; }
            public string LawyerLastName { get; set; }
        }
    }
}

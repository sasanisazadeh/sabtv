﻿using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Windows.Forms;
using System.Linq;


namespace sabtvaokala
{
    public static class ConnectionClass
    {
        private static string dbPath = Path.Combine(Application.StartupPath, "KanonDatabase.accdb");

        public static OleDbConnection GetConnection()
        {
            string dbPath = Path.Combine(Application.StartupPath, "KanonDatabase.accdb");
            string connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + dbPath + ";Persist Security Info=False;";
            return new OleDbConnection(connString);
        }

        public static bool IsLicenseNumberExists(string licenseNumber)
        {
            using (OleDbConnection conn = GetConnection())
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM TblLawyers WHERE LicenseNumber = ?";
                OleDbCommand cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("?", licenseNumber);
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        public static bool IsNationalCodeExists(string LawyerNationalCode)
        {
            using (OleDbConnection conn = GetConnection())
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM TblLawyers WHERE LawyerNationalCode = ?";
                OleDbCommand cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("?", LawyerNationalCode);
                return (int)cmd.ExecuteScalar() > 0;
            }
        }
        // متد جدید: جستجوی وکیل
        public static DataRow GetLawyerInfo(string searchTerm)
        {
            using (OleDbConnection conn = GetConnection())
            {
                conn.Open();
                string query = @"SELECT LawyerFirstName, LawyerLastName, LicenseNumber 
                               FROM TblLawyers 
                               WHERE LicenseNumber = ? OR 
                                     LawyerFirstName LIKE ? OR 
                                     LawyerLastName LIKE ?";

                OleDbCommand cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("@p1", searchTerm);
                cmd.Parameters.AddWithValue("@p2", $"%{searchTerm}%");
                cmd.Parameters.AddWithValue("@p3", $"%{searchTerm}%");

                DataTable dt = new DataTable();
                new OleDbDataAdapter(cmd).Fill(dt);
                return dt.Rows.Count > 0 ? dt.Rows[0] : null;
            }
        }
        // متد جدید: ذخیره حضور وکیل
        public static void SavePresence(string firstName, string lastName, string license, string date)
        {
            using (OleDbConnection conn = GetConnection())
            {
                conn.Open();
                string query = @"INSERT INTO TblLawyersPresence 
                               (LawyerFirstName, LawyerLastName, LicenseNumber, PresenceDate) 
                               VALUES (?, ?, ?, ?)";

                OleDbCommand cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("@p1", firstName);
                cmd.Parameters.AddWithValue("@p2", lastName);
                cmd.Parameters.AddWithValue("@p3", license);
                cmd.Parameters.AddWithValue("@p4", date);
                cmd.ExecuteNonQuery();
            }
        }
        // متد جدید: دریافت لیست روزانه
        public static DataTable GetDailyPresence(string date)
        {
            using (OleDbConnection conn = GetConnection())
            {
                conn.Open();
                string query = @"SELECT LawyerFirstName, LawyerLastName, LicenseNumber 
                               FROM TblLawyersPresence 
                               WHERE PresenceDate = ?";

                OleDbCommand cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("@p1", date);

                DataTable dt = new DataTable();
                new OleDbDataAdapter(cmd).Fill(dt);
                return dt;
            }
        }
        // متد جدید: گزارش هفتگی
        public static DataTable GetWeeklyReport(string startDate, string endDate)
        {
            using (OleDbConnection conn = GetConnection())
            {
                conn.Open();
                string query = @"SELECT PresenceDate, 
                       LawyerFirstName, LawyerLastName
                       FROM TblLawyersPresence
                       WHERE PresenceDate BETWEEN ? AND ?";

                OleDbCommand cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("@p1", startDate);
                cmd.Parameters.AddWithValue("@p2", endDate);

                DataTable dt = new DataTable();
                new OleDbDataAdapter(cmd).Fill(dt);
                // تبدیل به Enumerable و گروه‌بندی
                var grouped = dt.AsEnumerable()
                    .GroupBy(row => row.Field<string>("PresenceDate"))
                    .Select(g => new {
                        Date = g.Key,
                        Lawyers = string.Join("، ", g.Select(x =>
                            x.Field<string>("LawyerFirstName") + " " +
                            x.Field<string>("LawyerLastName"))),
                        Count = g.Count()
                    });

                // تبدیل نتیجه به DataTable
                DataTable result = new DataTable();
                result.Columns.Add("تاریخ");
                result.Columns.Add("وکلای حاضر");
                result.Columns.Add("تعداد", typeof(int));

                foreach (var item in grouped)
                {
                    result.Rows.Add(item.Date, item.Lawyers, item.Count);
                }
                return result;
            }
       
        }
    }
}

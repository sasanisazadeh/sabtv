﻿namespace sabtvaokala
{
    partial class BeLawyersInDep
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbldayindep = new System.Windows.Forms.Label();
            this.lbltimeindep = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtLawyerNameInDep = new System.Windows.Forms.TextBox();
            this.txtLawyerFamilyInDep = new System.Windows.Forms.TextBox();
            this.txtLicenseNumberInDep = new System.Windows.Forms.TextBox();
            this.btnSaveDep = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnPrintReport = new System.Windows.Forms.Button();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.dgvPresence = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPresence)).BeginInit();
            this.SuspendLayout();
            // 
            // lbldayindep
            // 
            this.lbldayindep.AutoSize = true;
            this.lbldayindep.Location = new System.Drawing.Point(56, 31);
            this.lbldayindep.Name = "lbldayindep";
            this.lbldayindep.Size = new System.Drawing.Size(64, 22);
            this.lbldayindep.TabIndex = 0;
            this.lbldayindep.Text = "امروز :";
            // 
            // lbltimeindep
            // 
            this.lbltimeindep.AutoSize = true;
            this.lbltimeindep.Location = new System.Drawing.Point(520, 36);
            this.lbltimeindep.Name = "lbltimeindep";
            this.lbltimeindep.Size = new System.Drawing.Size(64, 22);
            this.lbltimeindep.TabIndex = 1;
            this.lbltimeindep.Text = "ساعت :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 157);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "نام وکیل :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(397, 157);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 22);
            this.label4.TabIndex = 3;
            this.label4.Text = "نام خانوادگی :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(851, 157);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 22);
            this.label5.TabIndex = 4;
            this.label5.Text = "شماره پروانه :";
            // 
            // txtLawyerNameInDep
            // 
            this.txtLawyerNameInDep.Location = new System.Drawing.Point(110, 154);
            this.txtLawyerNameInDep.Name = "txtLawyerNameInDep";
            this.txtLawyerNameInDep.Size = new System.Drawing.Size(267, 28);
            this.txtLawyerNameInDep.TabIndex = 5;
            this.txtLawyerNameInDep.TextChanged += new System.EventHandler(this.txtLawyerNameInDep_TextChanged);
            // 
            // txtLawyerFamilyInDep
            // 
            this.txtLawyerFamilyInDep.Location = new System.Drawing.Point(524, 154);
            this.txtLawyerFamilyInDep.Name = "txtLawyerFamilyInDep";
            this.txtLawyerFamilyInDep.Size = new System.Drawing.Size(298, 28);
            this.txtLawyerFamilyInDep.TabIndex = 6;
            this.txtLawyerFamilyInDep.TextChanged += new System.EventHandler(this.txtLawyerFamilyInDep_TextChanged);
            // 
            // txtLicenseNumberInDep
            // 
            this.txtLicenseNumberInDep.Location = new System.Drawing.Point(978, 154);
            this.txtLicenseNumberInDep.Name = "txtLicenseNumberInDep";
            this.txtLicenseNumberInDep.Size = new System.Drawing.Size(157, 28);
            this.txtLicenseNumberInDep.TabIndex = 7;
            this.txtLicenseNumberInDep.TextChanged += new System.EventHandler(this.txtLicenseNumberInDep_TextChanged);
            // 
            // btnSaveDep
            // 
            this.btnSaveDep.Location = new System.Drawing.Point(1170, 154);
            this.btnSaveDep.Name = "btnSaveDep";
            this.btnSaveDep.Size = new System.Drawing.Size(130, 35);
            this.btnSaveDep.TabIndex = 8;
            this.btnSaveDep.Text = "ثبت";
            this.btnSaveDep.UseVisualStyleBackColor = true;
            this.btnSaveDep.Click += new System.EventHandler(this.btnSaveDep_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 300);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(198, 22);
            this.label1.TabIndex = 9;
            this.label1.Text = "تعداد وکلای حاضر امروز :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(844, 22);
            this.label2.TabIndex = 10;
            this.label2.Text = "برای ثبت حضور وکیل محترم در دپارتمان معاضدت ، لطفا یکی از مولفه های زیر ا وارد نم" +
    "وده و دکمه ثبت را کلیک نمایید .";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 248);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 22);
            this.label6.TabIndex = 11;
            this.label6.Text = "گزارش ها :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 355);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(262, 22);
            this.label7.TabIndex = 12;
            this.label7.Text = " تعداد وکلای حاضر در ماه جاری :  ";
            // 
            // btnPrintReport
            // 
            this.btnPrintReport.Location = new System.Drawing.Point(31, 423);
            this.btnPrintReport.Name = "btnPrintReport";
            this.btnPrintReport.Size = new System.Drawing.Size(150, 46);
            this.btnPrintReport.TabIndex = 13;
            this.btnPrintReport.Text = "چاپ گزارش";
            this.btnPrintReport.UseVisualStyleBackColor = true;
            this.btnPrintReport.Click += new System.EventHandler(this.btnPrintReport_Click);
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(200, 31);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(64, 22);
            this.lblDate.TabIndex = 14;
            this.lblDate.Text = "label8";
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Location = new System.Drawing.Point(637, 36);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(75, 22);
            this.lblTime.TabIndex = 15;
            this.lblTime.Text = "lblTime";
            // 
            // dgvPresence
            // 
            this.dgvPresence.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPresence.Location = new System.Drawing.Point(401, 284);
            this.dgvPresence.Name = "dgvPresence";
            this.dgvPresence.RowHeadersWidth = 51;
            this.dgvPresence.RowTemplate.Height = 24;
            this.dgvPresence.Size = new System.Drawing.Size(888, 260);
            this.dgvPresence.TabIndex = 16;
            // 
            // BeLawyersInDep
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1326, 721);
            this.Controls.Add(this.dgvPresence);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.btnPrintReport);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSaveDep);
            this.Controls.Add(this.txtLicenseNumberInDep);
            this.Controls.Add(this.txtLawyerFamilyInDep);
            this.Controls.Add(this.txtLawyerNameInDep);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbltimeindep);
            this.Controls.Add(this.lbldayindep);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "BeLawyersInDep";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "فرم ثبت حضور روزانه وکلا در دپارتمان معاضدت";
            ((System.ComponentModel.ISupportInitialize)(this.dgvPresence)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbldayindep;
        private System.Windows.Forms.Label lbltimeindep;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtLawyerNameInDep;
        private System.Windows.Forms.TextBox txtLawyerFamilyInDep;
        private System.Windows.Forms.TextBox txtLicenseNumberInDep;
        private System.Windows.Forms.Button btnSaveDep;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnPrintReport;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.DataGridView dgvPresence;
    }
}
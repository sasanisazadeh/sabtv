﻿using System;
using System.Globalization;

namespace sabtvaokala
{
    public static class PersianDateTimeExtensions
    {
        // محاسبه شروع هفته شمسی (شنبه)
        public static DateTime GetStartOfPersianWeek(this DateTime date)
        {
            PersianCalendar pc = new PersianCalendar();
            DateTime persianDate = pc.ToDateTime(date.Year, date.Month, date.Day, 0, 0, 0, 0);

            // محاسبه شنبه هفته جاری
            int delta = (int)persianDate.DayOfWeek - (int)DayOfWeek.Saturday;
            if (delta < 0) delta += 7;
            return pc.AddDays(persianDate, -delta);
        }

        // تبدیل به رشته تاریخ شمسی
        public static string ToPersianString(this DateTime date)
        {
            PersianCalendar pc = new PersianCalendar();
            return $"{pc.GetYear(date)}/{pc.GetMonth(date):00}/{pc.GetDayOfMonth(date):00}";
        }
    }
}
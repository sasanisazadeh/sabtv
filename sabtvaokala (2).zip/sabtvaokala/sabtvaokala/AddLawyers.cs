﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using sabtvaokala;
using System.Globalization;

namespace sabtvaokala
{
    public partial class AddLawyers : Form
    {
        public AddLawyers()
        {
            InitializeComponent();
            dtpRegisteryDate.Value = DateTime.Now;
            dtpRegisteryDate.Format = DateTimePickerFormat.Custom;
            dtpRegisteryDate.CustomFormat = "yyyy/MM/dd";
            dtpRegisteryDate.RightToLeft = RightToLeft.Yes;
            dtpRegisteryDate.Value = DateTime.Now;
        }

        private string GetPersianDate()
        {
            var pc = new System.Globalization.PersianCalendar();
            return $"{pc.GetYear(dtpRegisteryDate.Value)}/{pc.GetMonth(dtpRegisteryDate.Value):00}/{pc.GetDayOfMonth(dtpRegisteryDate.Value):00}";
        }


        private void BtnLawyerSave_Click(object sender, EventArgs e)
        {
            try
            {// 1. بررسی پر بودن فیلدهای اجباری
                if (string.IsNullOrEmpty(txtLawyerFirstName.Text) ||
                    string.IsNullOrEmpty(txtLawyerLastName.Text) ||
                    string.IsNullOrEmpty(txtLicenseNumber.Text) ||
                    string.IsNullOrEmpty(txtLawyerPhoneNumber.Text) ||
                    string.IsNullOrEmpty(txtLawyerAddress.Text) ||
                    string.IsNullOrEmpty(txtLawyerCityJob.Text) ||
                    string.IsNullOrEmpty(txtLawyerNationalCode.Text))
                {
                    MessageBox.Show("پر کردن فیلدهای ستاره‌دار الزامی است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 2. بررسی طول کد ملی (10 رقم)
                if (txtLawyerNationalCode.Text.Length != 10)
                {
                    MessageBox.Show("کد ملی باید 10 رقمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (txtLawyerPhoneNumber.Text.Length != 11)
                {
                    MessageBox.Show("کد ملی باید 11 رقمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 3. بقیه کدهای ثبت.

                using (OleDbConnection conn = ConnectionClass.GetConnection())
                {
                    conn.Open();
                    string query = @"INSERT INTO TblLawyers 
                           (LawyerFirstName, LawyerLastName, LawyerNationalCode, 
                            LicenseNumber, LawyerPhoneNumber, LawyerCityJob, 
                            RegisteryDate, LawyerAddress) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        // اضافه کردن پارامترها با نوع داده مشخص
                        cmd.Parameters.Add("@p1", OleDbType.VarWChar).Value = txtLawyerFirstName.Text;
                        cmd.Parameters.Add("@p2", OleDbType.VarWChar).Value = txtLawyerLastName.Text;
                        cmd.Parameters.Add("@p3", OleDbType.VarWChar).Value = txtLawyerNationalCode.Text;
                        cmd.Parameters.Add("@p4", OleDbType.VarWChar).Value = txtLicenseNumber.Text;
                        cmd.Parameters.Add("@p5", OleDbType.VarWChar).Value = txtLawyerPhoneNumber.Text;
                        cmd.Parameters.Add("@p6", OleDbType.VarWChar).Value = txtLawyerCityJob.Text;
                        cmd.Parameters.Add("@p7", OleDbType.VarWChar).Value = GetPersianDate();
                        cmd.Parameters.Add("@p8", OleDbType.VarWChar).Value = txtLawyerAddress.Text;

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("ثبت با موفقیت انجام شد");
                        LoadLawyersData(); // به روزرسانی گرید
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"خطا: {ex.Message}\nلطفاً مقادیر ورودی را بررسی کنید");
            }

        }
        private void LoadLawyersData()
        {
            try
            {
                using (OleDbConnection conn = ConnectionClass.GetConnection())
                {
                    // اصلاح کوئری (حذف ویرگول اضافه بعد از [آدرس])
                    string query = "SELECT LawyerFirstName as [نام], LawyerLastName as [نام خانوادگی], " +
                                 "LawyerNationalCode as [کد ملی], LicenseNumber as [شماره پروانه], " +
                                 "LawyerPhoneNumber as [تلفن], LawyerAddress as [آدرس] FROM TblLawyers";

                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dgvLawyers.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا در بارگذاری داده‌ها: " + ex.Message);
            }
        }

        private void BtnLawyerNew_Click(object sender, EventArgs e)
        {
            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is TextBox)
                    ((TextBox)ctrl).Clear();
            }
            dtpRegisteryDate.Value = DateTime.Now;
        }
        private void AddLawyers_Load(object sender, EventArgs e)
        {
            // تنظیمات ظاهری DataGridView
            dgvLawyers.RightToLeft = RightToLeft.Yes;
            dgvLawyers.ReadOnly = true;
            dgvLawyers.AllowUserToAddRows = false;
            dgvLawyers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvLawyers.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvLawyers.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 9, FontStyle.Bold);
            dgvLawyers.Font = new Font("Tahoma", 9);

            // بارگذاری داده‌ها
            LoadLawyersData();
        }

        private void BtnLawyerRefresh_Click(object sender, EventArgs e)
        {
            LoadLawyersData();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            var mainForm = Application.OpenForms["MainForm"] as MainForm;

            if (mainForm != null)
            {
                mainForm.Show(); // نمایش فرم اصلی
                this.Close(); // بستن فرم فعلی
            }
            else
            {
                MessageBox.Show("فرم اصلی یافت نشد!");
            }
        }

        private void txtLawyerNationalCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            // فقط اجازه ورود اعداد و کلیدهای کنترلی (مثل Backspace)
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; // جلوگیری از ورود کاراکتر غیرمجاز
                MessageBox.Show("فقط عدد مجاز است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtLicenseNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            // فقط اجازه ورود اعداد و کلیدهای کنترلی (مثل Backspace)
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; // جلوگیری از ورود کاراکتر غیرمجاز
                MessageBox.Show("فقط عدد مجاز است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtLawyerPhoneNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            // فقط اجازه ورود اعداد و کلیدهای کنترلی (مثل Backspace)
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; // جلوگیری از ورود کاراکتر غیرمجاز
                MessageBox.Show("فقط عدد مجاز است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}

﻿namespace sabtvaokala
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.مدیریتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.افزودنوویرایشمشخصاتاعضاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.گزارشعملکرداعضاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.جسجوToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتکشیکروزانهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مدیریتافرادمراجعهکنندهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتاطلاعاتاولیهمراجعهکنندهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتمشاورهرایگانToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتپروندهمعاضدتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.گزارشآماریToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.جستجومراجعهکنندهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.دربارهبرنامهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.خروجToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.مدیریتToolStripMenuItem,
            this.مدیریتافرادمراجعهکنندهToolStripMenuItem,
            this.دربارهبرنامهToolStripMenuItem,
            this.خروجToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1330, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // مدیریتToolStripMenuItem
            // 
            this.مدیریتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.افزودنوویرایشمشخصاتاعضاToolStripMenuItem,
            this.گزارشعملکرداعضاToolStripMenuItem,
            this.جسجوToolStripMenuItem,
            this.ثبتکشیکروزانهToolStripMenuItem});
            this.مدیریتToolStripMenuItem.Name = "مدیریتToolStripMenuItem";
            this.مدیریتToolStripMenuItem.Size = new System.Drawing.Size(107, 24);
            this.مدیریتToolStripMenuItem.Text = "مدیریت اعضا";
            // 
            // افزودنوویرایشمشخصاتاعضاToolStripMenuItem
            // 
            this.افزودنوویرایشمشخصاتاعضاToolStripMenuItem.Name = "افزودنوویرایشمشخصاتاعضاToolStripMenuItem";
            this.افزودنوویرایشمشخصاتاعضاToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.افزودنوویرایشمشخصاتاعضاToolStripMenuItem.Text = "افزودن و ویرایش  مشخصات اعضا";
            this.افزودنوویرایشمشخصاتاعضاToolStripMenuItem.Click += new System.EventHandler(this.افزودنوویرایشمشخصاتاعضاToolStripMenuItem_Click);
            // 
            // گزارشعملکرداعضاToolStripMenuItem
            // 
            this.گزارشعملکرداعضاToolStripMenuItem.Name = "گزارشعملکرداعضاToolStripMenuItem";
            this.گزارشعملکرداعضاToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.گزارشعملکرداعضاToolStripMenuItem.Text = "گزارش عملکرد اعضا";
            // 
            // جسجوToolStripMenuItem
            // 
            this.جسجوToolStripMenuItem.Name = "جسجوToolStripMenuItem";
            this.جسجوToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.جسجوToolStripMenuItem.Text = "جسجو";
            // 
            // ثبتکشیکروزانهToolStripMenuItem
            // 
            this.ثبتکشیکروزانهToolStripMenuItem.Name = "ثبتکشیکروزانهToolStripMenuItem";
            this.ثبتکشیکروزانهToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.ثبتکشیکروزانهToolStripMenuItem.Text = "ثبت کشیک روزانه";
            this.ثبتکشیکروزانهToolStripMenuItem.Click += new System.EventHandler(this.ثبتکشیکروزانهToolStripMenuItem_Click);
            // 
            // مدیریتافرادمراجعهکنندهToolStripMenuItem
            // 
            this.مدیریتافرادمراجعهکنندهToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ثبتاطلاعاتاولیهمراجعهکنندهToolStripMenuItem,
            this.ثبتمشاورهرایگانToolStripMenuItem,
            this.ثبتپروندهمعاضدتToolStripMenuItem,
            this.گزارشآماریToolStripMenuItem,
            this.جستجومراجعهکنندهToolStripMenuItem});
            this.مدیریتافرادمراجعهکنندهToolStripMenuItem.Name = "مدیریتافرادمراجعهکنندهToolStripMenuItem";
            this.مدیریتافرادمراجعهکنندهToolStripMenuItem.Size = new System.Drawing.Size(190, 24);
            this.مدیریتافرادمراجعهکنندهToolStripMenuItem.Text = "مدیریت افراد مراجعه کننده";
            // 
            // ثبتاطلاعاتاولیهمراجعهکنندهToolStripMenuItem
            // 
            this.ثبتاطلاعاتاولیهمراجعهکنندهToolStripMenuItem.Name = "ثبتاطلاعاتاولیهمراجعهکنندهToolStripMenuItem";
            this.ثبتاطلاعاتاولیهمراجعهکنندهToolStripMenuItem.Size = new System.Drawing.Size(293, 26);
            this.ثبتاطلاعاتاولیهمراجعهکنندهToolStripMenuItem.Text = "ثبت اطلاعات اولیه مراجعه کننده";
            this.ثبتاطلاعاتاولیهمراجعهکنندهToolStripMenuItem.Click += new System.EventHandler(this.ثبتاطلاعاتاولیهمراجعهکنندهToolStripMenuItem_Click);
            // 
            // ثبتمشاورهرایگانToolStripMenuItem
            // 
            this.ثبتمشاورهرایگانToolStripMenuItem.Name = "ثبتمشاورهرایگانToolStripMenuItem";
            this.ثبتمشاورهرایگانToolStripMenuItem.Size = new System.Drawing.Size(293, 26);
            this.ثبتمشاورهرایگانToolStripMenuItem.Text = "ثبت مشاوره رایگان";
            // 
            // ثبتپروندهمعاضدتToolStripMenuItem
            // 
            this.ثبتپروندهمعاضدتToolStripMenuItem.Name = "ثبتپروندهمعاضدتToolStripMenuItem";
            this.ثبتپروندهمعاضدتToolStripMenuItem.Size = new System.Drawing.Size(293, 26);
            this.ثبتپروندهمعاضدتToolStripMenuItem.Text = "ثبت پرونده معاضدت";
            // 
            // گزارشآماریToolStripMenuItem
            // 
            this.گزارشآماریToolStripMenuItem.Name = "گزارشآماریToolStripMenuItem";
            this.گزارشآماریToolStripMenuItem.Size = new System.Drawing.Size(293, 26);
            this.گزارشآماریToolStripMenuItem.Text = "گزارش آماری";
            // 
            // جستجومراجعهکنندهToolStripMenuItem
            // 
            this.جستجومراجعهکنندهToolStripMenuItem.Name = "جستجومراجعهکنندهToolStripMenuItem";
            this.جستجومراجعهکنندهToolStripMenuItem.Size = new System.Drawing.Size(293, 26);
            this.جستجومراجعهکنندهToolStripMenuItem.Text = "جستجو مراجعه کننده";
            // 
            // دربارهبرنامهToolStripMenuItem
            // 
            this.دربارهبرنامهToolStripMenuItem.Name = "دربارهبرنامهToolStripMenuItem";
            this.دربارهبرنامهToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.دربارهبرنامهToolStripMenuItem.Text = "درباره برنامه";
            // 
            // خروجToolStripMenuItem
            // 
            this.خروجToolStripMenuItem.Name = "خروجToolStripMenuItem";
            this.خروجToolStripMenuItem.Size = new System.Drawing.Size(55, 24);
            this.خروجToolStripMenuItem.Text = "خروج";
            this.خروجToolStripMenuItem.Click += new System.EventHandler(this.خروجToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::sabtvaokala.Properties.Resources.kanoon;
            this.pictureBox1.Location = new System.Drawing.Point(1095, 31);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(203, 233);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1330, 721);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "برنامه ثبت مشخصات ارباب رجوع در دپارتمان معاضدت";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem مدیریتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem افزودنوویرایشمشخصاتاعضاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem گزارشعملکرداعضاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem جسجوToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مدیریتافرادمراجعهکنندهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتاطلاعاتاولیهمراجعهکنندهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتمشاورهرایگانToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتپروندهمعاضدتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem گزارشآماریToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem جستجومراجعهکنندهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem دربارهبرنامهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem خروجToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem ثبتکشیکروزانهToolStripMenuItem;
    }
}